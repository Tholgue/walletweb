from setuptools import setup

setup(
    name='walletweb',
    version='0.0.1',
    install_requires=[
        'python3',
        'flask',
        'schedule',
        'sqlite',
        'pytz'
    ],
)